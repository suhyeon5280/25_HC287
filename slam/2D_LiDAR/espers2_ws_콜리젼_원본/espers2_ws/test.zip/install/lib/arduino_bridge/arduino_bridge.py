#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
import serial
from geometry_msgs.msg import Twist
import time

class ArduinoBridge(Node):
    def __init__(self):
        super().__init__('arduino_bridge')

        # 시리얼 포트 설정
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 115200)

        port = self.get_parameter('port').value
        baud = self.get_parameter('baudrate').value

        self.get_logger().info(f"Connecting to Arduino on {port} at {baud} baud...")
        self.ser = serial.Serial(port, baud, timeout=0.1)
        time.sleep(2)  # 아두이노 리셋 대기

        # /cmd_vel 구독
        self.create_subscription(Twist, '/cmd_vel', self.cmd_vel_callback, 10)

    def cmd_vel_callback(self, msg):
        # 간단한 차동 구동 변환 (m/s 단위 그대로 전송)
        # 선속도: msg.linear.x
        # 각속도: msg.angular.z
        wheel_base = 0.3  # 바퀴 간 거리 (m)
        v_r = msg.linear.x + (msg.angular.z * wheel_base / 2.0)
        v_l = -(msg.linear.x - (msg.angular.z * wheel_base / 2.0))

        # 아두이노로 전송 (형식: "v_r,v_l,\n")
        cmd = f"{v_r:.2f},{v_l:.2f},\n"
        self.ser.write(cmd.encode())

def main(args=None):
    rclpy.init(args=args)
    node = ArduinoBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()


